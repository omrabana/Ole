/* ********************************************************************************************************************** */
/*  Copyright (C) 2010 Siemens Aktiengesellschaft. All rights reserved.                                                   */
/*  The software is provided for AWP demo purposes only, using this software is at your own risk.                              */
/* ********************************************************************************************************************** */

    function DoLocalLanguageChange(oSelect) {
        SetLangCookie(oSelect.value);
        top.window.location.reload();
    }
  
    function SetLangCookie(value) {
        var strval = "siemens_automation_language=";  
            // this is the cookie by which the webserver detects the desired language,
            // the name is defined and required by the used webserver 
            // (if the value should be written to a PLC variable, the name has to be mapped with the 'Use' option of 
            //  AWP_In_Variable, since the length of STEP 7 symbols is restricted to 24 characters)
        strval = strval + value;
        strval = strval + "; path=/ ;";
            // set path to the whole application, since otherwise (default) path would be restricted to the requesting page
            
            // use expiration if this cookie should live longer than the current browser session
            //    var now      = new Date();
            //    var endttime = new Date(now.getTime() + expiration);
            //    strval = strval + "; expires=" + endttime.toGMTString() + ";";
            
        document.cookie = strval;
    }
  
  
    function OnSubmitLanguage(formobj) {
        var selobj = formobj.Language;
        var lang = selobj.options[selobj.selectedIndex];
        SetLangCookie(lang.value);
        return true; // allow formdata to be submitted
            // alternatively dont use a submit button, reload immediately on change
    }

/* ********************************************************************************************************************** */
/*  Copyright (C) 2010 Siemens Aktiengesellschaft. All rights reserved.                                                   */
/*  The software is provided for AWP demo purposes only, using this software is at your own risk.                              */
/* ********************************************************************************************************************** */
